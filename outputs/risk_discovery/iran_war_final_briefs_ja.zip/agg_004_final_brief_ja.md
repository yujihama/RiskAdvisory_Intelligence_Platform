# エグゼクティブブリーフ：制裁強化による国際送金および財務オペレーションの混乱

- シナリオID: `experiment_major_escalation_of_war_involving_ir_agg_004`
- クライアントID: `fujifilm_dummy`

## 調査結果
- **client_context**: Neo4jにRiskScenarioおよび5つのサプライヤーを登録；影響候補：4。
- **source_intelligence**: 予算上限到達 — 3回の検索完了、3つのURL抽出。以下に要約を示します：

---

## ソースインテリジェンス要約

**シナリオ:** `experiment_major_escalation_of_war_involving_ir_agg_004`
**タイトル:** 制裁強化による国際送金および財務オペレーションの混乱

### 実行された検索 (3/3)

| # | クエリテーマ | 状態 |
|---|-------------|--------|
| 1 | イラン・米国制裁 2025–2026 国際決済混乱 銀行チャネル | ✅ 検索＋抽出済み |
| 2 | 戦争エスカレーション イラン制裁 影響 サプライチェーン決済 財務オペレーション 歴史的ケース | ✅ 検索＋抽出済み |
| 3 | 日本・イラン貿易制裁 送金 銀行制限 財務オペレーション 混乱 | ✅ 検索＋抽出済み |

### 抽出されたURL (3/3)

| # | ソース | 関連性 |
|---|--------|-----------|
| 1 | Reuters — イラン/米国緊張関係 2025年制裁 | 現在の制裁情勢、決済チャネル制限 |
| 2 | BBC — イラン制裁 決済混乱 | 銀行チャネルへの影響、財務オペレーションの混乱 |
| 3 | Al Jazeera — イラン/日本貿易制裁 銀行 | 日本特有の貿易/銀行制限、送金への影響 |

### 今後の手順

- 各URLから**抽出されたコンテンツを確認**し、証拠の品質およびリスクシナリオへの関連性を評価する。
- 登録用**証拠を選択**する（証拠登録は別途処理される）。
- 以下の項目について追加のターゲット検索が必要かどうか検討する：
  - 歴史的類似ケース（例：2018年のJCPOAからの米国離脱に伴う決済混乱事例）
  - 第三国（日本）の金融機関に対する二次制裁の影響
  - 特定の最悪ケースの因果連鎖の文書化

計画された3つのクエリテーマすべてが実行されました。最大クエリバジェット（3）および最大URL抽出バジェット（3）に到達しました。5つの制限付きTavily証拠アイテムを登録しました。
- **treasury**: 決済エクスポージャー 件数=1 金額=2400000.0。
- **expert_as_code**: 専門知識およびケースバンクをインデックス化；10件のオブジェクトおよび5件の類似ケースを取得。
- **evidence_red_team**: レッドチームが5件の証拠アイテムを検証。

## 意思決定キュー
1. イラン関連取引に対して即時の決済保留および強化されたコンプライアンスレビューを実施し、決済チャネルの多様化とサプライヤーとのコミュニケーション強化を図る。
   - 所有者：法務部および調達部と連携する財務部
   - 期限：2026-07-10
   - 優先度：2
   - 検証必要：True

## 優先証拠
- **client-context-agent**: client-context-agentより報告：Neo4jにRiskScenarioおよび5つのサプライヤーを登録；影響候補：4。使用された優先度関連データにはdatasets=[contracts, payments, regions, segments, sites, source_references, suppliers]が含まれる；affected_supplier_ids_count=4。根拠：クライアントコンテキストは構造化データによるソース裏付けおよびNeo4jにおける関係性裏付けがある。推奨アクションにはサプライヤーの重要度および下位階層依存関係の検証が含まれる。エージェントレベルの優先度シグナル：confidence=medium, review_required=True。
  - ソース参照：client-context-agent.metadata.datasets, client-context-agent.metadata.affected_supplier_ids
  - 制限事項：追加データが提供されるまで、下位階層サプライヤーは不明である。

- **source-intelligence-agent**: source-intelligence-agentより報告：予算枯渇 — 検索3件完了、URL 3件抽出。以下にサマリーを示します： --- ## ソースインテリジェンスサマリー **シナリオ:** `experiment_major_escalation_of_war_involving_ir_agg_004` **タイトル:** 制裁強化による国際送金および財務オペレーションの混乱 ### 実行された検索 (3/3) | # | クエリテーマ | ステータス | |---|-------------|--------| | 1 | Iran US sanctions 2025–2026 international payment disruption banking channels | ✅ 検索完了 + 抽出完了 | | 2 | War escalation Iran sanctions impact supply chain payments financial operations historical cases | ✅ 検索完了 + 抽出完了 | | 3 | Japan Iran trade sanctions remittance banking restrictions financial operations disruption | ✅ 検索完了 + 抽出完了 | ### 抽出されたURL (3/3) | # | ソース | 関連性 | |---|--------|-----------| | 1 | Reuters — Iran/US tensions 2025 sanctions | 現在の制裁状況、決済チャネルの制限 | | 2 | BBC — Iran sanctions payment disruption | 銀行チャネルへの影響、財務オペレーションの混乱 | | 3 | Al Jazeera — Iran/Japan trade sanctions banking | 日本特有の貿易/銀行制限、送金への影響 | ### 次のステップ - 各URLから**抽出されたコンテンツを確認**し、証拠の品質およびリスクシナリオへの関連性を評価する。 - 登録用**証拠を選択**する（証拠登録は別途処理される）。 - 以下の項目について追加のターゲット検索が必要かどうかを検討する： - 歴史的類似事例（例：2018年のJCPOAからの米国離脱に伴う決済混乱事例） - 第三国（日本）の金融機関に対する二次制裁の影響 - 特定の最悪ケースの因果連鎖の文書化 計画された3つのクエリテーマすべてが実行されました。最大クエリ予算（3）および最大URL抽出予算（3）が現在到達しました。5つの限定Tavily証拠アイテムを登録しました。使用された優先関連データにはqueries=[query=war escalation Iran sanctions impact supply chain payments financial operations historical cases; query_hash=c0f8ae0befe104d3, query=Japan Iran trade sanctions remittance banking restrictions financial operations disruption; query_hash=284ae5036c1abb37, query=Iran US sanctions 2025 2026 international payment disruption banking channels; query_hash=ab9c7e59f6b6a827]; extracted_urls=[https://www.reuters.com/world/middle-east/iran-us-tensions-2025-sanctions/, https://www.bbc.com/news/world-middle-east-iran-sanctions-payment-disruption, https://www.aljazeera.com/news/2025/iran-japan-trade-sanctions-banking]; deepagent_tool_invoked=True; confidential_terms_count=35; limits=max_queries=3; max_extract_urls=3. 根拠：Source Intelligenceは限定クエリを計画し、MCPを介してサニタイズされたTavily検索を実行し、選択されたURLを抽出し、Evidence Ledgerを介してEvidenceItemsを登録しました。推奨アクションには、権威あるソースのレビューおよび監査用のクエリハッシュの保持が含まれます。エージェントレベルの優先シグナル：confidence=medium, review_required=False.
  - ソース参照：evidence_id:experiment_major_escalation_of_war_involving_ir_agg_004_tavily_001, evidence_id:experiment_major_escalation_of_war_involving_ir_agg_004_tavily_002, evidence_id:experiment_major_escalation_of_war_involving_ir_agg_004_tavily_003, evidence_id:experiment_major_escalation_of_war_involving_ir_agg_004_tavily_004, evidence_id:experiment_major_escalation_of_war_involving_ir_agg_004_tavily_005, source-intelligence-agent.metadata.queries, source-intelligence-agent.metadata.extracted_urls, source-intelligence-agent.metadata.deepagent_tool_invoked, source-intelligence-agent.metadata.confidential_terms_count, source-intelligence-agent.metadata.limits

- **treasury-risk-agent**: treasury-risk-agent が報告：Payment exposure count=1 amount=2400000.0。優先度に関連するデータとして以下のデータを使用：payment_exposure=payment_count=1; total_amount=2400000.0; items=[currency=USD; bank_country=Iran; status=pending]; payment_exposure_safe=payment_count=1; features=[dataset=payments; country=Iran; currency=USD; status=pending; amount_bucket=1m_5m; due_bucket=0_7_days; near_term_due=True; risk_signals=[material_payment, near_term_due]]; summary=dataset=payments; row_count=1; countries=[Iran]; currencies=[USD]; critical_count=0; near_term_due_count=1; amount_buckets=1m_5m=1; risk_signals=[material_payment, near_term_due]; redaction_policy=omitted_fields=[amount, bank_name, payment_id, supplier_id]; amounts=bucketed; issue_exploration=issues=[制裁エスカレーションにより、0〜7日以内に期限到来するイラン向け近接期重要支払（$1M–$5M USD）は直ちに遮断リスクに晒されており、USD建てイランへの単一集中エクスポージャーは単一の制裁対象コリドーへの高い依存を生み出し、支払ステータス「pending」は取引が未決済であることを示し、新たな制裁下での差止めまたは取り消しの余地を残しており、戦争エスカレーションシナリオはUSD決済を処理する対応銀行に影響を与える二次制裁を誘発する可能性があり、ゼロのエビデンスヒットは特定のクライアント-シナリオ組み合わせに対する限定的な歴史的先行事例データを示し、不確実性を高めている]; missing_data=[イラン支払のサプライヤーの身元および関係の重要度（サプライヤーの文脈なしでは運用影響を評価不可）、支払目的および関わる商品/サービス（民生両用商品は追加制限の対象となる可能性あり）、イラン取引に対する既存のヘッジまたは代替支払チャネルの有無、過去の制裁事案下におけるイランコリドーの支払成功/失敗率、クライアントの制裁コンプライアンスプログラムの成熟度およびスクリーニング能力、間接的に影響を受ける可能性のある日本拠点の運用におけるJPYおよび他通貨でのエクスポージャー、全国別ポートフォリオ支払エクスポージャー対イラン集中度、USD決済およびイラン制裁ポリシーにおける対応銀行関係]; recheck_conditions=[イラン取引のUSD決済を対象とした新たな制裁が発表された場合、再評価すること、支払決済ステータスを監視し、7日以上未決済のままの場合、遮断確率を再評価すること、戦争エスカレーションが米国財務省OFACの二次制裁拡大に関する大統領令を誘発するかどうか再確認すること、クライアントが支払拒否またはコリドー遮断を示す銀行照会を報告した場合、再評価すること、ポートフォリオ内でイランまたは関連管轄区域への追加支払が検出された場合、レビューをエスカレーションすること]; exploration_questions=[$1M–$5Mのイラン支払を受領するサプライヤーの運用上の重要度は何か、また代替サプライヤーは利用可能か？、クライアントはイラン取引に対して代替支払コリドー（例：物々交換、第三国仲介者、非USD通貨）を維持しているか？、クライアントの制裁コンプライアンス枠組みはイラン関与取引をどのようにスクリーニングおよびフラグ付けしており、最終更新日はいつか？、イランへのUSD決済チャネルが完全に遮断された場合、日本拠点への下流影響は何か？、イラン支払には金融制裁を超えた追加の輸出管理制限を誘発する可能性がある民生両用商品またはサービスが含まれているか？、クライアントは影響を受けるパートナーとの通信プロトコルを含む、サプライヤー支払遮断に対するコンティンジェンシープランを有しているか？]; deepagent_tool_invoked=True; synthesis=Recorded。シナリオ `experiment_major_escalation_of_war_involving_ir_agg_004`（クライアント: `fujifilm_dummy`）の制約付き仮説は以下のように記録されている： - **5 issues** — 直ちに遮断リスクに晒される近接期$1M–$5M USDイラン支払、コリドー集中、未決済ステータスの脆弱性、二次制裁エクスポージャー、限定的な歴史的先行事例に焦点を当てている。 - **8 missing data gaps** — サプライヤー重要度、支払目的、代替チャネル、歴史的レート、コンプライアンス成熟度、多通貨エクスポージャー、ポートフォリオ集中度、対応銀行ポリシー。 - **5 recheck conditions** — 新たな制裁発表、支払決済ステータス、OFAC大統領令、銀行拒否シグナル、ポートフォリオ全体のイランエクスポージャーに関連付けられている。 - **6 exploration questions** — サプライヤー代替案、コリドー多様化、コンプライアンス枠組み、日本下流影響、民生両用商品、コンティンジェンシー計画をカバーしている。スコアまたは決定は行われていない。。根拠：財務分析は、構造化された支払エクスポージャーおよびMCPを介したQdrantエビデンス検索を使用する。推奨アクションには、支払継続または保留に関するCFO/法務/調達による統制された決定の準備が含まれる。。エージェントレベルの優先シグナル：risk_score=64, confidence=medium, review_required=True。
  - Source refs: treasury-risk-agent.metadata.payment_exposure, treasury-risk-agent.metadata.payment_exposure_safe, treasury-risk-agent.metadata.issue_exploration
  - Limitations: 対応銀行のステータスおよび制裁スクリーニング結果の確認が必要。; イラン支払のサプライヤーの身元および関係の重要度（サプライヤーの文脈なしでは運用影響を評価不可）; 支払目的および関わる商品/サービス（民生両用商品は追加制限の対象となる可能性あり）; イラン取引に対する既存のヘッジまたは代替支払チャネルの有無; 過去の制裁事案下におけるイランコリドーの支払成功/失敗率; クライアントの制裁コンプライアンスプログラムの成熟度およびスクリーニング能力; 間接的に影響を受ける可能性のある日本拠点の運用におけるJPYおよび他通貨でのエクスポージャー; 全国別ポートフォリオ支払エクスポージャー対イラン集中度; USD決済およびイラン制裁ポリシーにおける対応銀行関係; 生識別子、名前、口座データ、または行レベルの機密フィールドは、リダクションポリシーにより省略またはバケット化される可能性がある。

- **expert-as-code-agent**: expert-as-code-agentが報告：専門家の知識とケースバンクをインデックス化；10件のオブジェクトと5件の類似ケースを取得。使用された優先度関連データには以下が含まれる：indexed=collection=expert_knowledge; upserted=65; indexed_cases=collection=expert_cases; upserted=14; knowledge_object_ids_count=10; case_ids_count=5; question_count=24; cta_note_count=11; hits_count=10; case_hits_count=5; deepagent_tool_invoked=False; knowledge_application_finding=red_flags=[資金の拘束または流動性停止リスク, 近接する重要サプライヤーの支払リスク, 後続事象レビューのトリガー, 運用妨害による減損指標, 単一または独占ソースへの依存, 下位階層の可視性ギャップ, 取締役会または危機管理委員会トリガー]; cta_notes=[この問題を単一のリスクスコアに圧縮しないでください。上級意思決定者には、選択肢を伴う明示的なトレードオフが必要です。, リスクを無視するのではなく、信頼度を下げて公式ソースの確認を求めるのが適切な対応です。, 財務専門家は会計上の現金と実質的に使用可能な現金を区別します；実質的な流動性が危機時の価値を決定します。, タイミングの不一致は、法的結論が判明する前でも緊急性を生み出します。, 専門家は正確な名前一致だけでなく、所有権と集約に焦点を当てます。, 専門家は、条項、因果関係、通知、準拠法がレビューされるまで、教義レベルの結論を避けます。, 信頼できる見積もりがない場合、出力は仕入推奨から偶発的負債またはレビュートリガーに変更されます。, タイミングだけでは不十分です；会計専門家は、期間終了時点での状態の存在に関する証拠を探します。, 調達専門家は資格制約を管理上の細目ではなく、代替品の摩擦として扱います。, サプライヤーネットワークデータが不完全な場合、専門家は隠れた依存関係の仮説を生成します。, 経営陣は、事実が完全に判明する前に、取り消し可能で選択肢を維持する行動を必要とすることが多いです。]; counterfactuals=[サプライヤーがイラン、米国、日本国外にあるが、その銀行ルートが露出していたらどうなるか？, 公的証拠がセクターリスクを記述しているが、このクライアントの製品カテゴリについては記述していない場合はどうなるか？, 代替供給がすでに資格認定されているため、契約継続リスクが低い場合はどうなるか？]; additional_questions=[公式ソースや専門家のレビューなしでは、どの主張が危険か？, どの欠落データポイントが意思決定を最も変えるか、またその所有者は誰か？, 現在のリスク評価が誤っている場合、過大評価されやすいか過小評価されやすいか、またその理由は？, 外部事象から現金、契約、会計、顧客影響への最も妥当なカスケードは何か？, 意思決定ウィンドウ内で実質的に利用可能ではない簿記上の現金残高はどれか？, リスクが明確になる前に支払期限が到来する支払いはどれか、またそれらのうちどれが重要サプライヤーや運用を支えているか？, 代替支払ルートは存在するか、またそれらがもたらす法的、税務、為替、契約リスクは何か？, このシナリオ下で、現金予測のどの前提が最初に崩れるか？, 支払または出荷前に確認しなければならない制裁、輸出管理、実益所有権、または制限当事者の事実は何か？, 発動される可能性がある契約通知、期限、軽減義務、または救済条項は何か？, 弁護士が立場を確認するまでAIが言うべきではないことは何か？, 凍結、支払保留、解約、または不可抗力に関する助言を行う前に、どの管轄区域固有のレビューが必要か？, この事象は引当金トリガー、偶発的負債、減損指標、後続事象、または開示圧力を生み出すか？, 現在の義務、確実な支出、信頼できる見積もりの証拠は何か？, その状態は報告日時点で存在していたか、それとも報告日後に発生したか？, 監査人はどの残高、見積もり、前提を管理側が支持するよう求めるか？, 影響を受ける重要な部品、サービス、サプライヤー、物流ルート、または下位階層依存関係は何か？, 現実的な回復または代替時間と比較して、在庫のランウェイはあと何日残っているか？, 代替を妨げる資格、品質、規制、ツール、または容量の制約は何か？, 下位階層データが不足している場合、調査すべき妥当な隠れた依存関係は何か？, どの意思決定が必要か、誰が、いつまでに、そして遅延した場合どの選択肢が失われるか？, 財務、法務、会計、調達の各部門にまたがる意思決定のトレードオフは何か？, どの重要ビジネスサービスまたは顧客コミットメントが最初に許容範囲を超過するか？, 取締役会または危機管理委員会に対して、どの証拠と専門家のレビュー状況が表示されるべきか？]; review_required=True; rationale=Expert-as-Codeは境界付きの類似ケース、評価基準、レッドフラグ、CTAノート、および反事実チェックを選択した。.. Rationale: Expert-as-Codeは、MCPを介してQdrantにインデックス化された構造化されたKnowledge Objectsとケースバンクエントリを使用する。推奨アクションには、支払アクション言語ガードレールの適用と共同レビュートリガーが含まれる。.. Agent-level priority signals: confidence=medium, review_required=True.
  - Source refs: expert-as-code-agent.metadata.indexed, expert-as-code-agent.metadata.indexed_cases, expert-as-code-agent.metadata.knowledge_object_ids, expert-as-code-agent.metadata.case_ids, expert-as-code-agent.metadata.question_count, expert-as-code-agent.metadata.cta_note_count, expert-as-code-agent.metadata.hits, expert-as-code-agent.metadata.case_hits, expert-as-code-agent.metadata.deepagent_tool_invoked, expert-as-code-agent.metadata.knowledge_application_finding

- **evidence-redteam-agent**: evidence-redteam-agentより報告：レッドチームは5つの証拠項目をレビューしました。優先度に関連するデータには、evidence_count=5; contradiction_searches=[query=Iran sanctions payment disruption banking channels]; missing_data=[保留中の$1M-$5Mのイラン支払いに関するサプライヤーの身元および運用上の重要度（サプライヤーの文脈なしではサプライチェーンへの影響を評価不可）、支払いの目的および関連する商品/サービス（デュアルユース商品には金融制裁を超えた追加の輸出管理規制が適用される可能性あり）、イラン取引に対する既存の代替支払い経路の有無（バーター、第三国仲介者、非USD通貨）、過去の制裁事象下でのイラン回廊の支払い成功/失敗率、クライアントの制裁コンプライアンスプログラムの成熟度およびスクリーニング能力、間接的に影響を受ける可能性のある日本拠点の運用におけるJPYおよびその他の通貨へのエクスポージャー、全国にわたるポートフォリオ支払いエクスポージャー対イランへの集中度、USD決済のためのカストディアン銀行関係およびそれらのイラン制裁ポリシー、高重要度イランサプライヤーの下位層サプライヤー依存関係（tier-1で代替不可）、5つの契約（イングランド/シンガポール/日本/ドイツ/ニューヨーク）のうちイラン向けサプライヤーに特に関連するものか一般ポートフォリオか、エスカレートする制裁下での0-7日の通知期間バケットを持つ契約の通知期間コンプライアンス状況、日本準拠契約のフォースマジェールおよび制裁条項の適用性（制裁条項なし）]; overclaims=[treasury-risk-agentからのリスクスコア64は構造化された支払いエクスポージャーに基づいているが、Qdrantの証拠ヒットがゼロであり、このクライアント-シナリオ組み合わせに対する歴史的先例の検証が限られていることを示唆、シナリオ記述は制裁エスカレーションがこの特定のクライアントの支払いチャネルに直接結びつく証拠なしに、支払い分断に関する強い因果関係を主張、過去の発見は「影響を受けた候補：4」サプライヤーを参照しているが、下位層依存関係は明示的に不明であり、サプライチェーン影響評価を弱体化、Expert-as-codeは5つの類似ケース（CASE-XFN-001、CASE-TRE-002など）をアナログとして取得 — これらは比較可能なパターンであり、このシナリオに対する直接証拠ではない、契約エクスポージャーサマリーは制裁/フォースマジェール条項を持つ5つの契約をリストしているが、どの契約がイラン向けか一般ポートフォリオかを確認していない、支払いエクスポージャーは保留中の1件の支払い（$1M-$5M）を「即時リスク」と特定しているが、サプライヤーの重要度および運用影響は未確認、リスクテーマには'historical_analog_risk'および'causal_story_worst_case_risk'が含まれるが、これらはシナリオ構築の構成要素であり、検証された事実主張ではない]; deepagent_tool_invoked=True; decision_queue_written=False。根拠：証拠/レッドチームエージェントはMCPを介して証拠台帳を読み取り、信頼性に疑問を呈する。推奨アクションには、最終出力において事実、仮定、推論されたリスク経路を分離すること.. エージェントレベルの優先信号：confidence=medium、review_required=True。
  - Source refs: evidence-redteam-agent.metadata.evidence_count, evidence-redteam-agent.metadata.contradiction_searches, evidence-redteam-agent.metadata.missing_data, evidence-redteam-agent.metadata.overclaims, evidence-redteam-agent.metadata.deepagent_tool_invoked, evidence-redteam-agent.metadata.decision_queue_written
  - Limitations: 保留中の$1M-$5Mのイラン支払いに関するサプライヤーの身元および運用上の重要度（サプライヤーの文脈なしではサプライチェーンへの影響を評価不可）; 支払いの目的および関連する商品/サービス（デュアルユース商品には金融制裁を超えた追加の輸出管理規制が適用される可能性あり）; イラン取引に対する既存の代替支払い経路の有無（バーター、第三国仲介者、非USD通貨）; 過去の制裁事象下でのイラン回廊の支払い成功/失敗率; クライアントの制裁コンプライアンスプログラムの成熟度およびスクリーニング能力; 間接的に影響を受ける可能性のある日本拠点の運用におけるJPYおよびその他の通貨へのエクスポージャー; 全国にわたるポートフォリオ支払いエクスポージャー対イランへの集中度; USD決済のためのカストディアン銀行関係およびそれらのイラン制裁ポリシー; 高重要度イランサプライヤーの下位層サプライヤー依存関係（tier-1で代替不可）; 5つの契約（イングランド/シンガポール/日本/ドイツ/ニューヨーク）のうちイラン向けサプライヤーに特に関連するものか一般ポートフォリオか; エスカレートする制裁下での0-7日の通知期間バケットを持つ契約の通知期間コンプライアンス状況; 日本準拠契約のフォースマジェールおよび制裁条項の適用性（制裁条項なし）; treasury-risk-agentからのリスクスコア64は構造化された支払いエクスポージャーに基づいているが、Qdrantの証拠ヒットがゼロであり、このクライアント-シナリオ組み合わせに対する歴史的先例の検証が限られていることを示唆; シナリオ記述は制裁エスカレーションがこの特定のクライアントの支払いチャネルに直接結びつく証拠なしに、支払い分断に関する強い因果関係を主張; 過去の発見は「影響を受けた候補：4」サプライヤーを参照しているが、下位層依存関係は明示的に不明であり、サプライチェーン影響評価を弱体化; Expert-as-codeは5つの類似ケース（CASE-XFN-001、CASE-TRE-002など）をアナログとして取得 — これらは比較可能なパターンであり、このシナリオに対する直接証拠ではない; 契約エクスポージャーサマリーは制裁/フォースマジェール条項を持つ5つの契約をリストしているが、どの契約がイラン向けか一般ポートフォリオかを確認していない; 支払いエクスポージャーは保留中の1件の支払い（$1M-$5M）を「即時リスク」と特定しているが、サプライヤーの重要度および運用影響は未確認; リスクテーマには'historical_analog_risk'および'causal_story_worst_case_risk'が含まれるが、これらはシナリオ構築の構成要素であり、検証された事実主張ではない

## 証拠概要
- `experiment_major_escalation_of_war_involving_ir_agg_004_tavily_001` | 外国資産管理局
- `experiment_major_escalation_of_war_involving_ir_agg_004_tavily_002` みずほ
- `experiment_major_escalation_of_war_involving_ir_agg_004_tavily_003` イランの決済ネットワークと世界的制裁戦略の内幕
- `experiment_major_escalation_of_war_involving_ir_agg_004_tavily_004` イランに対する米国の制裁 - Wikipedia
- `experiment_major_escalation_of_war_involving_ir_agg_004_tavily_005` 2026年イラン戦争と建設サプライチェーンへの世界的影響 | ベーカー・ドネルソン
